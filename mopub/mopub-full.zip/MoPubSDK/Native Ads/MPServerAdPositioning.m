//
//  MPServerAdPositioning.m
//  MoPub
//
//  Copyright (c) 2014 MoPub. All rights reserved.
//

#import "MPServerAdPositioning.h"

@implementation MPServerAdPositioning

+ (instancetype)positioning
{
    return [[[self class] alloc] init];
}

@end
