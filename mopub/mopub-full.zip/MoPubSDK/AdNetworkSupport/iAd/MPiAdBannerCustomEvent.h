//
//  MPiAdBannerCustomEvent.h
//  MoPub
//
//  Copyright (c) 2013 MoPub. All rights reserved.
//

#if __has_include(<MoPub/MoPub.h>)
    #import <MoPub/MoPub.h>
#else
    #import "MPBannerCustomEvent.h"
#endif

@interface MPiAdBannerCustomEvent : MPBannerCustomEvent

@end
