//
//  MPLastResortDelegate+EventKit.h
//  MoPub
//
//  Copyright (c) 2014 MoPub. All rights reserved.
//

#import "MPLastResortDelegate.h"
#import <EventKitUI/EventKitUI.h>

@interface MPLastResortDelegate (EventKit) <EKEventEditViewDelegate>

@end
