//
//  MPInterstitialCustomEventAdapter.h
//  MoPub
//
//  Copyright (c) 2012 MoPub, Inc. All rights reserved.
//

#import "MPBaseInterstitialAdapter.h"

#import "MPPrivateInterstitialCustomEventDelegate.h"

@interface MPInterstitialCustomEventAdapter : MPBaseInterstitialAdapter <MPPrivateInterstitialCustomEventDelegate>

@end
