//
//  MRError.m
//  MoPubSDK
//
//  Copyright (c) 2014 MoPub. All rights reserved.
//

#import "MRError.h"

NSString * const MoPubMRAIDAdsSDKDomain = @"com.mopub.iossdk.mraid";
